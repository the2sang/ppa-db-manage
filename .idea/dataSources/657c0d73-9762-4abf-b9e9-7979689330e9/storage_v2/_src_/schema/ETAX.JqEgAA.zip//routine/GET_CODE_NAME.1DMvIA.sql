create FUNCTION "GET_CODE_NAME" (v_gubun CHAR, v_code CHAR)
RETURN VARCHAR2
IS
v_retrun_name VARCHAR2 (100);
BEGIN
SELECT code_value
  into v_retrun_name
  FROM tb_code_info
 WHERE code_grp_id = UPPER(v_gubun)
   and code = v_code;
 return v_retrun_name;
end GET_CODE_NAME;
/

