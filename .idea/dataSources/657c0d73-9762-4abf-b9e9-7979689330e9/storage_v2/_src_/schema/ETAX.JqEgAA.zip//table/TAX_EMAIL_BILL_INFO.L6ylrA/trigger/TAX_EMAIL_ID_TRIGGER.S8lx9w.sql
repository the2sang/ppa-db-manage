create trigger TAX_EMAIL_ID_TRIGGER
    before insert
    on TAX_EMAIL_BILL_INFO
    for each row
BEGIN
  SELECT TAX_EMAIL_SEQ.NEXTVAL
  INTO   :new.id
  FROM   dual;
END;
/

